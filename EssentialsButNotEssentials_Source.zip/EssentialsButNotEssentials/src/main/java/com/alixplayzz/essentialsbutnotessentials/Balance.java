package com.alixplayzz.essentialsbutnotessentials;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;

public class Balance implements CommandExecutor {


    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {

        // BALANCE COMMAND (/balance)
        if (cmd.getName().equalsIgnoreCase("balance")) {
            if (sender instanceof Player) {

                // Creates file and file variables for "balances.yml"
                File file_balances = new File(EssentialsButNotEssentials.plugin.getDataFolder()+File.separator+
                        "balances.yml");
                if (!file_balances.exists()) {
                    try {
                        file_balances.createNewFile();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                FileConfiguration file_balances_config = YamlConfiguration.loadConfiguration(file_balances);

                // Changes values in "balances.yml"
                Player player = ((Player) sender).getPlayer();
                if (!file_balances_config.contains(player.getUniqueId().toString())) {
                    file_balances_config.set(player.getUniqueId().toString(), 0);
                    try {
                        file_balances_config.save(file_balances);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

                player.sendMessage(ChatColor.translateAlternateColorCodes('&', "&b[EBNE] " +
                        "&7Current Balance: &b") + file_balances_config.get(player.getUniqueId().toString()));

            }
        }


        // ECO COMMAND (/eco <give/remove/set> <bal amount>)
        if (cmd.getName().equalsIgnoreCase("eco")) {
            if (sender instanceof Player) {
                if (args.length >= 1) {
                    if (args[0].equalsIgnoreCase("give")) {

                        // Creates file and file variables for "balances.yml"
                        File file_balances = new File(EssentialsButNotEssentials.plugin.getDataFolder()+File.separator+
                                "balances.yml");
                        if (!file_balances.exists()) {
                            try {
                                file_balances.createNewFile();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                        FileConfiguration file_balances_config = YamlConfiguration.loadConfiguration(file_balances);

                        Player player = ((Player) sender).getPlayer();
                        file_balances_config.set(player.getUniqueId().toString(), file_balances_config.getInt(player.getUniqueId().toString()) + Integer.parseInt(args[1]));
                        try {
                            file_balances_config.save(file_balances);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        player.sendMessage(ChatColor.translateAlternateColorCodes('&', "&b[EBNE] &7Your balance " +
                                "is now: &b" + file_balances_config.get(player.getUniqueId().toString())));
                    }
                    if (args[0].equalsIgnoreCase("remove")) {

                        // Creates file and file variables for "balances.yml"
                        File file_balances = new File(EssentialsButNotEssentials.plugin.getDataFolder()+File.separator+
                                "balances.yml");
                        if (!file_balances.exists()) {
                            try {
                                file_balances.createNewFile();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                        FileConfiguration file_balances_config = YamlConfiguration.loadConfiguration(file_balances);

                        Player player = ((Player) sender).getPlayer();
                        file_balances_config.set(player.getUniqueId().toString(), file_balances_config.getInt(player.getUniqueId().toString()) - Integer.parseInt(args[1]));
                        try {
                            file_balances_config.save(file_balances);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        player.sendMessage(ChatColor.translateAlternateColorCodes('&', "&b[EBNE] &7Your balance " +
                                "is now: &b" + file_balances_config.get(player.getUniqueId().toString())));
                    }
                    if (args[0].equalsIgnoreCase("set")) {

                        // Creates file and file variables for "balances.yml"
                        File file_balances = new File(EssentialsButNotEssentials.plugin.getDataFolder()+File.separator+
                                "balances.yml");
                        if (!file_balances.exists()) {
                            try {
                                file_balances.createNewFile();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                        FileConfiguration file_balances_config = YamlConfiguration.loadConfiguration(file_balances);

                        Player player = ((Player) sender).getPlayer();
                        file_balances_config.set(player.getUniqueId().toString(), file_balances_config.getInt(player.getUniqueId().toString()) - file_balances_config.getInt(player.getUniqueId().toString()) + Integer.parseInt(args[1]));
                        try {
                            file_balances_config.save(file_balances);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        player.sendMessage(ChatColor.translateAlternateColorCodes('&', "&b[EBNE] &7Your balance " +
                                "is now: &b" + file_balances_config.get(player.getUniqueId().toString())));
                    }


                }

            }
        }

        return false;
    }

}
