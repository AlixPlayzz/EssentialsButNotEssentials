package com.alixplayzz.essentialsbutnotessentials;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public final class EssentialsButNotEssentials extends JavaPlugin {

    public static Plugin plugin;
    // -------------------------------------
    @Override
    public void onEnable() {
        // Plugin startup logic
        plugin = this;
        Bukkit.getPluginCommand("fly").setExecutor(new FlyMode());
        Bukkit.getPluginCommand("balance").setExecutor(new Balance());
        Bukkit.getPluginCommand("eco").setExecutor(new Balance());
        Bukkit.getPluginCommand("tnt").setExecutor(new TNT());
        Bukkit.getPluginCommand("spawnmob").setExecutor(new TNT());
        Bukkit.getPluginCommand("back").setExecutor(new Back());
        Bukkit.getPluginManager().registerEvents(new Back(), this);
        Bukkit.getConsoleSender().sendMessage(ChatColor.translateAlternateColorCodes('&', "&b[EBNE] &7Enabling.."));
        new BukkitRunnable() {
            @Override
            public void run() {
                Bukkit.getConsoleSender().sendMessage(ChatColor.translateAlternateColorCodes('&', "&b[EBNE] " +
                        "&7Successfully enabled!"));
            }
        }.runTaskLater(this, 60);

    }
    // ---------------------------------------

    @Override
    public void onDisable() {
        // Plugin shutdown logic
    }


}
