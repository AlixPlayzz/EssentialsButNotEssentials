package com.alixplayzz.essentialsbutnotessentials;

import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;

import java.util.HashMap;
import java.util.UUID;


public class Back implements CommandExecutor, Listener {

    public static HashMap<UUID, Location> player_location = new HashMap<UUID, Location>();

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        player_location.put(player.getUniqueId(), player.getLocation());
        player.sendMessage(ChatColor.translateAlternateColorCodes('&', "&b[EBNE] &7You died. Use &b/b" +
                "ack &7to return to death location."));
    }

    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (cmd.getName().equalsIgnoreCase("back")) {
            if (sender instanceof Player) {
                Player player = ((Player) sender).getPlayer();
                player.teleport(player_location.get(player.getUniqueId()));
                player.sendMessage(ChatColor.translateAlternateColorCodes('&', "&b[EBNE] &7Teleported to previous location."));
                return true;
            }
        } else {
            Player player = ((Player) sender).getPlayer();
            player_location.put(player.getUniqueId(), player.getLocation());
        }
        return false;
    }
}
