package com.alixplayzz.essentialsbutnotessentials;

public class Gamemode {
}
