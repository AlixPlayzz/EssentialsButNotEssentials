package com.alixplayzz.essentialsbutnotessentials;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

public class TNT implements CommandExecutor {

    // TNT/ANTIOCH COMMAND (/tnt)
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (cmd.getName().equalsIgnoreCase("tnt")) {
            if (sender instanceof Player) {
                Player player = ((Player) sender).getPlayer();
                Block block = player.getTargetBlock(null, 100);
                Location block_location = block.getLocation();
                World world = Bukkit.getServer().getWorld("world");
                world.spawnEntity(block_location, EntityType.PRIMED_TNT);
                player.sendMessage(ChatColor.translateAlternateColorCodes('&', "&b[EBNE] &7Summoned &cTNT &7at crosshair location."));
            }
        }
        if (cmd.getName().equalsIgnoreCase("spawnmob")) {
            if (sender instanceof Player) {
                if (args.length >= 1) {
                    if (args.length >= 2) {
                        int amountofmobs = Integer.parseInt(args[1]);
                        for (int i = 0; i < amountofmobs; i++) {
                            Player player = ((Player) sender).getPlayer();
                            Block block = player.getTargetBlock(null, 100);
                            Location block_location = block.getLocation().add(0, 1, 0);
                            World world = Bukkit.getServer().getWorld("world");
                            world.spawnEntity(block_location, EntityType.valueOf(args[0].toUpperCase()));
                        }
                        Player player = ((Player) sender).getPlayer();
                        player.sendMessage(ChatColor.translateAlternateColorCodes('&', "&b[EBNE] &7Summ" +
                                "oned &c" + amountofmobs + " " + args[0].toUpperCase() + "(s)" + " &7at crosshair location."));
                    } else {
                        Player player = ((Player) sender).getPlayer();
                        Block block = player.getTargetBlock(null, 100);
                        Location block_location = block.getLocation();
                        World world = Bukkit.getServer().getWorld("world");
                        world.spawnEntity(block_location, EntityType.valueOf(args[0].toUpperCase()));
                        player.sendMessage(ChatColor.translateAlternateColorCodes('&', "&b[EBNE] &7Summ" +
                                "oned &c" + args[0].toUpperCase() + " &7at crosshair location."));
                    }

                }
            }
        }


        return false;
    }
}
