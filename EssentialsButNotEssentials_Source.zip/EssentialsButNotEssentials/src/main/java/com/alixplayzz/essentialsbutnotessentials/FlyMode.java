package com.alixplayzz.essentialsbutnotessentials;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

public class FlyMode implements CommandExecutor {

    // FLY COMMAND (/fly [playername])
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (cmd.getName().equalsIgnoreCase("fly")) {
            if (sender instanceof Player) {
                if (args.length == 1) {
                    Player otherplayer = Bukkit.getServer().getPlayer(args[0]);
                    Player awesomeplayer = ((Player) sender).getPlayer();
                    if (otherplayer == null) {
                        awesomeplayer.sendMessage(ChatColor.
                                translateAlternateColorCodes('&', "&b[EBNE] &7Invalid player name."));
                        return false;
                    } else {
                        if (args[0].equalsIgnoreCase(otherplayer.getDisplayName())) {
                            if (otherplayer.getAllowFlight() == false) {
                                otherplayer.setAllowFlight(true);
                                Player player = ((Player) sender).getPlayer();
                                player.sendMessage(ChatColor.translateAlternateColorCodes('&', "&b[EBNE] " +
                                        "&7Fly mode enabled " +
                                        "for &b" + otherplayer.getDisplayName()));
                                otherplayer.sendMessage(ChatColor.translateAlternateColorCodes('&', "&b[EBNE] " + "&7Fly " +
                                        "mode enabled by&b " + player.getDisplayName()));

                            } else {
                                otherplayer.setAllowFlight(false);
                                Player player = ((Player) sender).getPlayer();
                                player.sendMessage(ChatColor.translateAlternateColorCodes('&', "&b[EBNE] " +
                                        "&7Fly mode disabled " +
                                        "for &b" + otherplayer.getDisplayName()));

                            }
                        }
                    }
                } else {
                    Player player = ((Player) sender).getPlayer();
                    if (player.getAllowFlight() == false) {
                        player.setAllowFlight(true);
                        player.sendMessage(ChatColor.translateAlternateColorCodes('&', "&b[EBNE] &7Fly mode enabled"));
                    } else {
                        player.setAllowFlight(false);
                        player.sendMessage(ChatColor.translateAlternateColorCodes('&', "&b[EBNE] &7Fly mode disabled"));
                    }
                }
            }
        }

        return false;
    }

}
